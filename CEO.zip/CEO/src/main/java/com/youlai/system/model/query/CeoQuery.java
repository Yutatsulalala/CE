package com.youlai.system.model.query;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Schema(description ="ceo分页查询对象")
@Data
public class CeoQuery {

    @Schema(description="关键字(ceo名称)")
    private String name;


    @Schema(description="任ceo时间")
    private Date time;


    @Schema(description="关键字(erp编码)")
    private String erp;


    @Schema(description="关键字(营服名称)")
    private String camps;

}
