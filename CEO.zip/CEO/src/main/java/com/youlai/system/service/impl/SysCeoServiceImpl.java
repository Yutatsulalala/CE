package com.youlai.system.service.impl;

import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.youlai.system.common.util.DateUtils;
import com.youlai.system.converter.CeoConverter;
import com.youlai.system.mapper.SysCeoMapper;
import com.youlai.system.model.bo.CeoBO;
import com.youlai.system.model.entity.SysCeo;
import com.youlai.system.model.form.CeoBaseForm;
import com.youlai.system.model.form.CeoForm;
import com.youlai.system.model.query.CeoPageQuery;
import com.youlai.system.model.query.CeoQuery;
import com.youlai.system.model.vo.*;
import com.youlai.system.service.SysCeoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ceo业务实现类
 *
 * @author yyc
 * @since 2024-05-14
 */
@Service
@RequiredArgsConstructor
public class SysCeoServiceImpl extends ServiceImpl<SysCeoMapper, SysCeo> implements SysCeoService {
    private final CeoConverter ceoConverter;
    @Override
    public List<CeoVO> listCeo(CeoQuery queryParams) {
        return null;
    }

    /**
     * 获取ceo分页列表
     * @param queryParams
     * @return
     */
    @Override
    public IPage<CeoPageVO> listPagedCeo(CeoPageQuery queryParams) {
        //得到分页得页数和大小
        int pageNum = queryParams.getPageNum();
        int pageSize = queryParams.getPageSize();
        Page<CeoBO> page =new Page<>(pageNum,pageSize);
        //将Date数据格式化为数据库日期形式
        DateUtils.toDatabaseFormat(queryParams,"startTime","endTime");
        System.out.println("keywords is here");
        System.out.println(queryParams.getKeywords());

        //查询数据
        Page<CeoBO> ceoPage = this.baseMapper.listPagedCeo(page,queryParams);
        return ceoConverter.bo2PageVO(ceoPage);
    }

    /**
     * 新增ceo
     * @param ceoForm ceo表单对象
     * @return
     */
    @Override
    public boolean saveCeo(CeoBaseForm ceoForm) {
        String ceoname = ceoForm.getName();
//        long count = this.count(new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, username));
//        Assert.isTrue(count == 0, "用户名已存在");

        // 实体转换 form->entity
        SysCeo entity = ceoConverter.form2Entity(ceoForm);
        // 新增用户
        boolean result = this.save(entity);
        return result;
    }

    @Override
    public CeoForm getCeoFormData(Long ceoId) {
        return this.baseMapper.getCeoFormData(ceoId);}

    @Override
    @Transactional
    public boolean updateCeo(Long ceoId, CeoBaseForm ceoForm) {

        String ceoname = ceoForm.getName();

//        long count = this.count(new LambdaQueryWrapper<SysCeo>()
//                .eq(SysCeo::getName, ceoname)
//                .ne(SysCeo::getId, ceoId)
//        );
//        Assert.isTrue(count == 0, "该ceo已存在");

        // form -> entity
        SysCeo entity = ceoConverter.form2Entity(ceoForm);
        // 修改用户
        boolean result = this.updateById(entity);

        return result;
    }

    /**
     * 删除用户
     *
     * @param idsStr 用户ID，多个以英文逗号(,)分割
     * @return true|false
     */
    @Override
    public boolean deleteCeo(String idsStr) {
        Assert.isTrue(StrUtil.isNotBlank(idsStr), "删除的用户数据为空");
        // 逻辑删除
        List<Long> ids = Arrays.stream(idsStr.split(","))
                .map(Long::parseLong)
                .collect(Collectors.toList());
        return this.baseMapper.updateCeoDeleted(ids,1);
    }

    /**
     * 回溯操作
     * @return
     */
    @Override
    public boolean backOperate() {
        return true;
    }

    /**
     * 获取导出用户列表
     *
     *
     * @return {@link List<UserExportVO>} 导出用户列表
     */
    @Override
    public List<CeoExportVO> listExportCeos(CeoPageQuery queryParams) {
        return this.baseMapper.listExportCeos();
    }

}
