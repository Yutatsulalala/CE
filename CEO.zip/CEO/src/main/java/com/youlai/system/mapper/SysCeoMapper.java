package com.youlai.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.youlai.system.model.bo.CeoBO;
import com.youlai.system.model.entity.SysCeo;
import com.youlai.system.model.form.CeoForm;
import com.youlai.system.model.query.CeoPageQuery;
import com.youlai.system.model.query.UserPageQuery;
import com.youlai.system.model.vo.CeoExportVO;
import com.youlai.system.model.vo.CeoFormVO;
import com.youlai.system.model.vo.UserExportVO;
import com.youlai.system.plugin.mybatis.annotation.DataPermission;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysCeoMapper extends BaseMapper<SysCeo> {
    /**
     * 获取ceo分页列表
     * @param page
     * @param queryParams 查询参数
     * @return
     */
//    @DataPermission(deptAlias = "c")
    Page<CeoBO> listPagedCeo(Page<CeoBO> page, CeoPageQuery queryParams);

    /**
     * 获取ceo表单详情
     *
     * @param ceoId ceoID
     * @return
     */
    CeoForm getCeoFormData(Long ceoId);

//    @DataPermission(deptAlias = "u")
    List<CeoExportVO> listExportCeos();

    Boolean updateCeoDeleted(List<Long> ceoIds,int deleteFlag);

}
