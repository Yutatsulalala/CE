package com.youlai.system.converter;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.youlai.system.model.bo.CeoBO;
import com.youlai.system.model.entity.SysCeo;
import com.youlai.system.model.entity.SysDept;
import com.youlai.system.model.form.CeoBaseForm;
import com.youlai.system.model.form.CeoForm;
import com.youlai.system.model.form.DeptForm;
import com.youlai.system.model.vo.CeoFormVO;
import com.youlai.system.model.vo.CeoPageVO;
import com.youlai.system.model.vo.CeoVO;
import com.youlai.system.model.vo.DeptVO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

/**
 * ceo对象转换器
 */
@Mapper(componentModel= "spring")
public interface CeoConverter {
    CeoForm entity2Form(SysCeo entity);
    CeoVO entity2Vo(SysCeo entity);

    @InheritInverseConfiguration(name = "entity2Form")
    SysCeo form2Entity(CeoBaseForm ceoForm);

    Page<CeoPageVO> bo2PageVO(Page<CeoBO> bo);

    Page<CeoFormVO> form2PageVO(Page<CeoForm> bo);
}
