package com.youlai.system.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.databind.ser.Serializers;
import com.youlai.system.common.base.BaseEntity;
import lombok.Data;

import java.util.Date;

/**
 * Ceo实体表
 */
@Data
public class SysCeo extends BaseEntity {
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 营服id
     */
    private Long campId;

    /**
     * 营服名称
     */
    private String campName;
    /**
     * ceo名称
     */
    private String name;
    /**
     * ERP编码
     */
    private String erp;
    /**
     * 用工类型
     */
    private String contract;
    /**
     * 到岗时间
     */
    private Date workTime;
    /**
     * 任职ceo时间
     */
    private Date ceoTime;
    /**
     * 任职文件
     */
    private String documents;

}
