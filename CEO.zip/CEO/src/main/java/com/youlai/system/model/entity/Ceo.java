package com.youlai.system.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.youlai.system.common.base.BaseEntity;
import lombok.Data;

import java.util.Date;

public class Ceo extends BaseEntity {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String camp_id;
    private Long create_user;
    private String name;
    private String erp;
    private String contract;
    private Date work_time;
    private Date ceo_time;
    private String document;
    private Integer deleted;
}
