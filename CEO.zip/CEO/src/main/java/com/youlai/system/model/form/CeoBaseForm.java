package com.youlai.system.model.form;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.Month;
import java.time.Year;
import java.util.Date;

@Schema(description = "ceo基本表单对象")
@Data
public class CeoBaseForm {

    @Schema(description = "id")
    @TableId(type = IdType.AUTO)
    private Long id;

    @Schema(description="营服id")
//    @NotBlank(message = "营服不能为空")
    private Long campId;

    @Schema(description="ceo姓名")
    @NotBlank(message = "用户名不能为空")
    private String name;

    @Schema(description="ERP编码")
    @NotBlank(message = "ERP编码不能为空")
    private String erp;

    @Schema(description="用工类型")
    @NotBlank(message = "用工类型不能为空")
    private String contract;

    @Schema(description="任职文件")
    private String documents;

    @Schema(description = "到岗时间")
    private Date workTime;

    @Schema(description = "任ceo时间")
    private Date ceoTime;

    @Schema(description = "任ceo时间")
    private Date createTime;

    @Schema(description = "任ceo时间")
    private Date updateTime;

}
