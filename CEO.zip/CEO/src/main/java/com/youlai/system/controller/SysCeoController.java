package com.youlai.system.controller;

import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.youlai.system.common.result.PageResult;
import com.youlai.system.common.result.Result;
import com.youlai.system.model.form.CeoBaseForm;
import com.youlai.system.model.form.CeoForm;
import com.youlai.system.model.form.UserForm;
import com.youlai.system.model.query.CeoPageQuery;
import com.youlai.system.model.query.CeoQuery;
import com.youlai.system.model.query.UserPageQuery;
import com.youlai.system.model.vo.CeoExportVO;
import com.youlai.system.model.vo.CeoFormVO;
import com.youlai.system.model.vo.CeoPageVO;
import com.youlai.system.model.vo.UserPageVO;
import com.youlai.system.plugin.dupsubmit.annotation.PreventDuplicateSubmit;
import com.youlai.system.service.SysCeoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

/**
 * ceo控制器
 *
 * @author yyc
 * @since 2024/5/14
 */
@Tag(name="08.ceo接口")
@RestController
@RequestMapping("/api/v1/ceo")
@RequiredArgsConstructor
public class SysCeoController {
    private final SysCeoService ceoService ;

    @Operation(summary = "ceo分页列表")
    @GetMapping("/page")
    public PageResult<CeoPageVO> listPagedCeo(
            @ParameterObject CeoPageQuery queryParams
    ) {
        IPage<CeoPageVO> result = ceoService.listPagedCeo(queryParams);
        return PageResult.success(result);
    }


    @Operation(summary = "新增ceo")
    @PostMapping
//    @PreAuthorize("@ss.hasPerm('sys:ceo:add')")
//    @PreventDuplicateSubmit
    public Result saveCeo(
            @RequestBody @Valid CeoBaseForm ceoForm
    ) {
        boolean result = ceoService.saveCeo(ceoForm);
        return Result.judge(result);
    }

    @Operation(summary = "获取ceo表单数据")
    @GetMapping("/{ceoId}/form")
    public Result<CeoForm> getCeoForm(
            @Parameter(description = "ceoId") @PathVariable Long ceoId
    ) {
        CeoForm ceoForm = ceoService.getCeoFormData(ceoId);
        return Result.success(ceoForm);
    }


    @Operation(summary = "修改用户")
    @PutMapping(value = "/{userId}")
    @PreAuthorize("@ss.hasPerm('sys:user:edit')")
    public Result updateCeo(
            @Parameter(description = "用户ID") @PathVariable Long userId,
            @RequestBody @Validated CeoBaseForm ceoBaseForm) {
        boolean result = ceoService.updateCeo(userId, ceoBaseForm);
        return Result.judge(result);
    }

    @Operation(summary = "删除用户")
    @DeleteMapping("/{ids}")
    @PreAuthorize("@ss.hasPerm('sys:user:delete')")
    public Result deleteCeo(
            @Parameter(description = "用户ID，多个以英文逗号(,)分割") @PathVariable String ids
    ) {
        boolean result = ceoService.deleteCeo(ids);
        return Result.judge(result);
    }

    @Operation(summary = "导出用户")
    @GetMapping("/export")
    public void exportUsers(HttpServletResponse response, CeoPageQuery queryParams) throws IOException {
        String fileName = "用户列表.xlsx";
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));

        List<CeoExportVO> exportCeoLists = ceoService.listExportCeos(queryParams);
        EasyExcel.write(response.getOutputStream(), CeoExportVO.class).sheet("小Ceo列表")
                .doWrite(exportCeoLists);
    }

}
