package com.youlai.system.model.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Schema(description = "ceo分页对象")
@Data
public class CeoPageVO {

    @Schema(description="ceoID")
    private Long id;

    @Schema(description = "ceo姓名")
    private String name;

    @Schema(description = "营服Name")
    private String campName;

    @Schema(description = "ERP编码")
    private String erp;

    @Schema(description = "用工类型")
    private String contract;

    @Schema(description = "任职文件")
    private String documents;

    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime createTime;
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime updateTime;

    @Schema(description = "到岗时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime workTime;

    @Schema(description = "任ceo时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime ceoTime;
}
