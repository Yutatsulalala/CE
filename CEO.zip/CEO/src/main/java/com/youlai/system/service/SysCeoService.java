package com.youlai.system.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.youlai.system.model.entity.SysCeo;
import com.youlai.system.model.form.CeoBaseForm;
import com.youlai.system.model.form.CeoForm;
import com.youlai.system.model.query.CeoPageQuery;
import com.youlai.system.model.query.CeoQuery;
import com.youlai.system.model.vo.*;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * ceo业务接口
 *
 * @author yyc
 * @since 2024/5/14
 */
public interface SysCeoService extends IService<SysCeo> {
    /**
     * ceo列表
     *
     * @return
     */
    List<CeoVO> listCeo(CeoQuery queryParams);

    /**
     * ceo分页列表
     * @param queryParams
     * @return
     */
    IPage<CeoPageVO> listPagedCeo(CeoPageQuery queryParams);

    /**
     *新增用户
     * @param ceoForm ceo表单对象
     * @return
     */
    boolean saveCeo(CeoBaseForm ceoForm);

    /**
     * 获取ceo表单数据
     * @param ceoId
     * @return
     */
    CeoForm getCeoFormData(Long ceoId);


    @Transactional
    boolean updateCeo(Long ceoId, CeoBaseForm ceoForm);

    boolean deleteCeo(String idsStr);

    boolean backOperate();

    /**
     * 获取导出用户列表
     *
     * @param queryParams
     * @return
     */
    List<CeoExportVO> listExportCeos(CeoPageQuery queryParams);
}
