package com.youlai.system.model.bo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CeoBO {

    private Long id;

    private String name;

    private String campName;

    private String erp;


    private String contract;


    private String documents;


    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime updateTime;


    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime workTime;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime ceoTime;
}
